/*
 * Class : DIT/FT/1B/03
 * Admission Number : p2037084
 * Name : Tan Jing Wen
 */
package JPRG2;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import javax.swing.JOptionPane;

/**
 *
 * @author jw
 */
public class IO {
    Event[] origarray;
    String[] result;
    int arraylength;
    
    public IO() throws IOException{
        file();
    }
    
        // read event.txt file 
    public void file() throws IOException {
        BufferedReader br;
        FileReader fr;

        try {
            fr = new FileReader("C:\\Users\\jw\\OneDrive\\Documents\\SP\\DIT1B03\\JAVA\\NetBeansProjects\\JPRGAssignment\\src\\JPRG2\\event.txt");
            br = new BufferedReader(fr);

            // read the first line
            String n = br.readLine();
            arraylength = Integer.parseInt(n);
            System.out.println(n);
            origarray = new Event[arraylength];
            for (int i = 0; i < arraylength; i++) {
                n = br.readLine();
                result = n.split(";");
                System.out.println(result[0] + result[1] + Double.parseDouble(result[2]) + result[3] + result[4]);
                origarray[i] = new Event(result[0], result[1], result[3], Double.parseDouble(result[2]));
//                System.out.println(arraylength);
//                System.out.println(origarray[i].getName());
            }

        } catch (FileNotFoundException e) {
            JOptionPane.showMessageDialog(null, "ERROR ! File is not found.", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (IOException e) {
            System.err.format("IOException: %s%n", e);
        }

    }
}
