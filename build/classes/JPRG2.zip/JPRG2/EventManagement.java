/*
 * Class : DIT/FT/1B/03
 * Admission Number : p2037084
 * Name : Tan Jing Wen
 */
package JPRG2;

import javax.swing.JOptionPane;
import java.util.*;
import java.io.*;

/**
 *
 * @author jw
 */
public class EventManagement {

    String registerr = "", fee = "";
    double fees;

    public EventManagement() throws IOException {
        this.file = new IO();
    }
    
    IO file ;
    
//
//    // read event.txt file 
//    public void file() throws IOException {
//        BufferedReader br;
//        FileReader fr;
//
//        try {
//            fr = new FileReader("C:\\Users\\jw\\OneDrive\\Documents\\SP\\DIT1B03\\JAVA\\NetBeansProjects\\JPRGAssignment\\src\\JPRG2\\event.txt");
//            br = new BufferedReader(fr);
//
//            // read the first line
//            String n = br.readLine();
//            arraylength = Integer.parseInt(n);
//            System.out.println(n);
//            origarray = new Event[arraylength];
//            for (int i = 0; i < arraylength; i++) {
//                n = br.readLine();
//                result = n.split(";");
//                System.out.println(result[0] + result[1] + Double.parseDouble(result[2]) + result[3] + result[4]);
//                origarray[i] = new Event(result[0], result[1], result[3], Double.parseDouble(result[2]));
////                System.out.println(arraylength);
////                System.out.println(origarray[i].getName());
//            }
//
//        } catch (FileNotFoundException e) {
//            JOptionPane.showMessageDialog(null, "ERROR ! File is not found.", "Error", JOptionPane.ERROR_MESSAGE);
//        } catch (IOException e) {
//            System.err.format("IOException: %s%n", e);
//        }
//
//    }

    // DISPLAY
    public String Display() {
        String result = "S\\N\tName\tOrganizer\tDate&Time\tFees\n\n";
        for (int i = 0; i < file.origarray.length; i++) {
            result += (i + 1) + "\t"
                    + file.origarray[i].getName() + "\t"
                    + file.origarray[i].getOrganizer() + "\t"
                    + file.origarray[i].getDatentime() + "\t"
                    + file.origarray[i].getFees() + "\n";
        }
        return result;
    }

    // ADD
    public void Add(String name, String organizer, String datentime, Double fees) {
        // ADVANCED REQUIREMENTS : no duplicated event name can be added
        int repeat;

        // 1 =  duplicate // 2 = no duplicate
        repeat = isDuplicate(name, file.origarray);
        if (repeat == 1) {
            JOptionPane.showMessageDialog(
                    null,
                    "Error ! The event name entered is duplicated !"
                    + "\nPlease enter a new event name again.",
                    "Error",
                    JOptionPane.ERROR_MESSAGE);
        } else {

            // ADDING NEW EVENT
            Event[] newarray = new Event[file.origarray.length + 1];
            for (int i = 0; i < file.origarray.length; i++) {
                newarray[i] = file.origarray[i];
            }
            newarray[file.origarray.length] = new Event(name, organizer, datentime, fees);
            file.origarray = newarray;
            JOptionPane.showMessageDialog(null, "Event added successfully !", "Message", JOptionPane.DEFAULT_OPTION);
            Display();
        }
    }

    // DELETE
    public void Delete(String deletename) {

        int deleteindex, check = 0;
        for (int i = 0; i < file.origarray.length; i++) {
            if (deletename.equals(file.origarray[i].getName())) {
                deleteindex = i;
                check = 1;
                Event[] newarray = new Event[file.origarray.length - 1];
                for (int h = 0, j = 0; h < file.origarray.length; h++) {
                    if (h != deleteindex) {
                        newarray[j++] = file.origarray[h];
                    }
                }
                JOptionPane.showMessageDialog(
                        null,
                        "Event deleted!",
                        "Message",
                        JOptionPane.INFORMATION_MESSAGE);
                file.origarray = newarray;
                Display();
            }
        }
        if (check == 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "Cannot find the event \" " + deletename + "\" to delete !",
                    "Event",
                    JOptionPane.ERROR_MESSAGE);
        }
    }

    // SEARCH BY NAME
    public String Search1(String searchname) {
        String result = "S\\N\tName\tOrganizer\tDate&Time\tFees\n\n";
        int check = 0, j = 1;
        for (int i = 0; i < file.origarray.length; i++) {
            if (searchname.contains(file.origarray[i].getName())) {
                check = 1;
                result += (j++) + "\t"
                        + file.origarray[i].getName() + "\t"
                        + file.origarray[i].getOrganizer() + "\t"
                        + file.origarray[i].getDatentime() + "\t"
                        + file.origarray[i].getFees() + "\n";
            }
        }
        if (check == 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "Cannot find the event \" " + searchname + "\" !! Please search again.",
                    "Event",
                    JOptionPane.ERROR_MESSAGE);
        }
        return result;
    }

    // SEARCH BY FEES
    public String Search2(Double searchfees) {
        String result = "S\\N\tName\tOrganizer\tDate&Time\tFees\n\n";
        int check = 0, j = 1;
        for (int i = 0; i < file.origarray.length; i++) {
            if (searchfees >= file.origarray[i].getFees()) {
                check = 1;
                result += (j++) + "\t"
                        + file.origarray[i].getName() + "\t"
                        + file.origarray[i].getOrganizer() + "\t"
                        + file.origarray[i].getDatentime() + "\t"
                        + file.origarray[i].getFees() + "\n";
            }
        }
        if (check == 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "Cannot find the event below $" + searchfees + "!! Please search again.",
                    "Event",
                    JOptionPane.ERROR_MESSAGE);
        }
        return result;
    }

    // REGISTER BY NAME
    public String Register(String register) {
        String result = "";
        int check = 0;
        // check whether user have register the same event

        for (int i = 0; i < file.origarray.length; i++) {
            if (register.equals(file.origarray[i].getName())) {
                check = 1;
                registerr += "*  " + file.origarray[i].getName() + "\n";
                fees += file.origarray[i].getFees();
                result = "You have registered for the following event(s) :" + "\n" + registerr + "\n\n" + "The cost is $" + fees;
            }
        }
        if (check == 0) {
            JOptionPane.showMessageDialog(
                    null,
                    "Cannot find the event \" " + register + "\" !!",
                    "Event",
                    JOptionPane.ERROR_MESSAGE);
        }
        return result;
    }

    // : no duplicate event name can be added
    public int isDuplicate(String name, Event[] array) {
        int check = 0;
        for (int i = 0; i < array.length; i++) {
            if (name.equals(array[i].getName())) {
                check = 1;
            }
        }
        if (check == 1) {
            return 1;
        } else {
            return 2;
        }
    }

}
