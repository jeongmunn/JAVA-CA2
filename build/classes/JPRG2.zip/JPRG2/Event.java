/*
 * Class : DIT/FT/1B/03
 * Admission Number : p2037084
 * Name : Tan Jing Wen
 */
package JPRG2;

import javax.swing.JOptionPane;
import java.util.Arrays;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author jw
 */

public class Event {
   public String name , organizer , datentime , result ;
   int count;
   double fees;
   
    public Event(String name,String organizer,String datentime,double fees){
        this.name = name ;
        this.organizer = organizer ;
        this.datentime = datentime ;
        this.fees = fees ;
    }
    
    public String getName(){
        return this.name;
    }
    
    public String getOrganizer(){
        return this.organizer;
    }
    
    public String getDatentime(){
        return this.datentime;
    }

    public double getFees(){
        return this.fees;
    }
}

